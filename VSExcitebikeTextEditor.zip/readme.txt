﻿VS. Excitebike Text Editor 1.0.0.14919
Coded by: Shawn M. Crawford [sleepy9090]
April 7, 2018

-Requires .NET Framework 3.5

VS. Excitebike Text Editor 
Program to edit the the text in the VS. Exciteboke ROM for the Nintendo VS. System 

-Tested with headered Excitebike (VS).nes.nes ROM with MD5 Checksum: F1E27389B5F9D9CC8036EFD10DFEB0A5

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.0.14919 April 7, 2018
-initial version


